

@include('layouts.clientheader')	
            <!-- wrapper -->	
            <div id="wrapper"> 
                <!--content -->  
                <div class="content">
                    <!--section --> 
                    <section>
                        <!-- container -->
                        <div class="container">
                            <!-- profile-edit-wrap -->
                            <div class="profile-edit-wrap">
                                <div class="profile-edit-page-header">
                                    <h2 class="center"> {{Auth()->user()->Firstname}} book your room </h2>
                                </div>
                                <div class="row" >
                                    <div class="col-md-2" style="height: 300px; " >
                                        <!-- start of content-->          

                                        <img src="/storage/room/{{$room->cover_image}}" style="width: 300px;height: 80%;">

                                        <!-- end of content-->                                        
                                    </div>
                                    <div class="col-md-3" style="margin-left: 110px;font-size: 30px;">
                                        
                                        <div class="box-widget widget-posts">
                                        <div class="box-widget-content">
                                            <ul>

                                                    <li class="clearfix">
                                                        <div class="widget-posts-descr">
                                                            <span class="widget-posts-date"><i class="fa fa-info-circle"> </i>&nbsp<strong>{{$room->name}}</strong></span>
                                                            <span class="widget-posts-date"><i class="fa fa-money"></i> {{$room->price}} Frw</span>
                                                            <span class="widget-posts-date"><i class="fa fa-calendar-check-o"></i> 21 Mar 2017 </span>
                                                            <span class="widget-posts-date"><i class="fa fa-calendar-check-o"></i> 21 Mar 2017 </span>
                                                        </div>
                                                    </li>
                                                
                                            </ul>
                                        
                                        </div>       
                                    </div>
                                    </div>
                                    <div class="col-xs-5">
<div class="box-widget widget-posts">
    <div class="box-widget-content">
        <ul>
                <li class="clearfix">
                    <div class="widget-posts-descr">
                        <form action="{{action('BookingController@store')}}" method="POST">
                            @csrf
                            <input type="hidden" name="id" value="{{$id}}">
                        <span class="widget-posts-date"><i class="fa fa-info-circle"> </i>&nbsp<strong>number of adult </strong>

                            <input type="number" name="adult">
                        </span>
                        <span class="widget-posts-date"><i class="fa fa-money"></i> Number of child
                            <input type="number" name="child">

                        </span>
                        <span class="widget-posts-date"><i class="fa fa-calendar-check-o"></i> Check In <br>
                            <input type="date" name="checkin">

                         </span>
                        <span class="widget-posts-date"><i class="fa fa-calendar-check-o"></i> Check Out <br>

                            <input type="date" name="checkout">
                        </span>
                            <input type="submit" value="Save" >
                        </form>
                    </div>
                </li>
        </ul>
    
    </div>       
</div>
                                    </div>
                                </div>
                            </div>
                            <!--profile-edit-wrap end -->
                        </div>
                        <!--container end -->
                    </section>
                    <!-- section end -->
                    <div class="limit-box fl-wrap"></div>
                    <!--section -->
                    @include('layouts.getintouch')
                    <!-- section end -->
                </div>
            </div>
            <!-- wrapper end -->
            <!--footer -->
 @include('layouts.adminfooter')           