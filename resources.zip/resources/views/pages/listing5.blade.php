<!DOCTYPE HTML>
<html lang="en">
    
<!-- Mirrored from citybook.kwst.net/dashboard-myprofile.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 19 Apr 2018 17:36:02 GMT -->
<head>
        <!--=============== basic  ===============-->
        <meta charset="UTF-8">
        <title>Citybook -Directory Listing Template</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
        <meta name="robots" content="index, follow"/>
        <meta name="keywords" content=""/>
        <meta name="description" content=""/>
        <!--=============== css  ===============--> 
        <link type="text/css" rel="stylesheet" href="css/reset.css">
        <link type="text/css" rel="stylesheet" href="css/plugins.css">
        <link type="text/css" rel="stylesheet" href="css/style.css">
        <link type="text/css" rel="stylesheet" href="css/color.css">
        <!--=============== favicons ===============-->
        <link rel="shortcut icon" href="images/favicon.ico">
    </head>
    <body>
        <!-- loader -->
        <div class="loader-wrap">
            <div class="pin"></div>
            <div class="pulse"></div>
        </div>
        <!--  loader end -->
        <!-- Main   -->
        <div id="main">
            <!-- header  -->
            <header class="main-header dark-header fs-header sticky">
                <div class="header-inner">
                    <div class="logo-holder">
                        <a href="index.html"><img src="images/logo.png" alt=""></a>
                    </div>
                    <div class="header-search vis-header-search">
                        <div class="header-search-input-item">
                            <input type="text" placeholder="Keywords" value=""/>
                        </div>
                        <div class="header-search-select-item">
                            <select data-placeholder="All Categories" class="chosen-select" >
                                <option>All Categories</option>
                                <option>Shops</option>
                                <option>Hotels</option>
                                <option>Restaurants</option>
                                <option>Fitness</option>
                                <option>Events</option>
                            </select>
                        </div>
                        <button class="header-search-button" onclick="window.location.href='listing.html'">Search</button>
                    </div>
                    <div class="show-search-button"><i class="fa fa-search"></i> <span>Search</span></div>
                    <a href="dashboard-add-listing.html" class="add-list">Add Listing <span><i class="fa fa-plus"></i></span></a>
                    <div class="header-user-menu">
                        <div class="header-user-name">
                            <span><img src="images/avatar/4.jpg" alt=""></span>
                            Hello , Alisa
                        </div>
                        <ul>
                            <li><a href="dashboard-myprofile.html"> Edit profile</a></li>
                            <li><a href="dashboard-add-listing.html"> Add Listing</a></li>
                            <li><a href="dashboard-bookings.html">  Bookings  </a></li>
                            <li><a href="dashboard-review.html"> Reviews </a></li>
                            <li><a href="#">Log Out</a></li>
                        </ul>
                    </div>
                    <!-- nav-button-wrap--> 
                    <div class="nav-button-wrap color-bg">
                        <div class="nav-button">
                            <span></span><span></span><span></span>
                        </div>
                    </div>
                    <!-- nav-button-wrap end-->
                    <!--  navigation --> 
                    <div class="nav-holder main-menu">
                        <nav>
                            <ul>
                                <li>
                                    <a href="#">Home <i class="fa fa-caret-down"></i></a>
                                    <!--second level -->   
                                    <ul>
                                        <li><a href="index.html">Parallax Image</a></li>
                                        <li><a href="index2.html">Video</a></li>
                                        <li><a href="index3.html">Map</a></li>
                                        <li><a href="index4.html">Slideshow</a></li>
                                        <li><a href="index5.html">Sider</a></li>
                                    </ul>
                                    <!--second level end-->
                                </li>
                                <li>
                                    <a href="#">Listings <i class="fa fa-caret-down"></i></a>
                                    <!--second level -->
                                    <ul>
                                        <li><a href="listing.html">Column map</a></li>
                                        <li><a href="listing2.html">Column map 2</a></li>
                                        <li><a href="listing3.html">Fullwidth Map</a></li>
                                        <li><a href="listing4.html">Fullwidth Map 2</a></li>
                                        <li><a href="listing5.html">Without Map</a></li>
                                        <li><a href="listing6.html">Without Map 2</a></li>
                                        <li>
                                            <a href="#">Single <i class="fa fa-caret-down"></i></a>
                                            <!--third  level  -->
                                            <ul>
                                                <li><a href="listing-single.html">Style 1</a></li>
                                                <li><a href="listing-single2.html">Style 2</a></li>
                                                <li><a href="listing-single3.html">Style 3</a></li>
                                            </ul>
                                            <!--third  level end-->
                                        </li>
                                    </ul>
                                    <!--second level end-->
                                </li>
                                <li>
                                    <a href="blog.html">News</a>
                                </li>
                                <li>
                                    <a href="#" class="act-link">Pages <i class="fa fa-caret-down"></i></a>
                                    <!--second level -->   
                                    <ul>
                                        <li><a href="about.html">About</a></li>
                                        <li><a href="contacts.html">Contacts</a></li>
                                        <li><a href="author-single.html">User single</a></li>
                                        <li><a href="how-itworks.html">How it Works</a></li>
                                        <li><a href="pricing-tables.html">Pricing</a></li>
                                        <li><a href="dashboard-myprofile.html">User Dasboard</a></li>
                                        <li><a href="blog-single.html">Blog Single</a></li>
                                        <li><a href="dashboard-add-listing.html">Add Listing</a></li>
                                        <li><a href="404.html">404</a></li>
                                        <li><a href="coming-soon.html">Coming Soon</a></li>
                                        <li><a href="header2.html">Header 2</a></li>
                                        <li><a href="footer-fixed.html">Footer Fixed</a></li>
                                    </ul>
                                    <!--second level end-->                                
                                </li>
                            </ul>
                        </nav>
                    </div>
                    <!-- navigation  end -->
                </div>
            </header>
            <!--  header end -->    
            <!-- wrapper -->    
            <div id="wrapper"> 
                <!--content -->  
                <div class="content">
                    <!--section --> 
                    <section>
                        <!-- container -->
                        <div class="container">
                            <!-- profile-edit-wrap -->
                            <div class="profile-edit-wrap">
                                <div class="profile-edit-page-header">
                                    <h2>Admin profile</h2>
                                    <div class="breadcrumbs"><a href="#">Admin</a><a href="#">Dasboard</a><span>Admin profile</span></div>
                                </div>
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="fixed-bar fl-wrap">
                                            <div class="user-profile-menu-wrap fl-wrap">
                                                <!-- user-profile-menu end-->
                                                <!-- user-profile-menu-->
                                                <div class="user-profile-menu">
                                                    <h3>Listings</h3>
                                                    <ul>
                                                        <li><a href="dashboard-listing-table.html"><i class="fa fa-map-marker"></i> Location  </a></li>
                                                        <li><a href="dashboard-bookings.html"><i class="fa fa-user-o"></i> Hotel Owners  </a></li>
                                                        <li><a href="listing5.html"><i class="fa fa-th-list"></i>  Hotels </a></li>
                                                        <li><a href="dashboard-listing-table.html"><i class="fa fa-th-list"></i>  Room Types  </a></li>
                                                        <li><a href="dashboard-review.html"><i class="fa fa-th-list"></i>  Clients  </a></li>
                                                        <li><a href="dashboard-bookings.html"> <i class="fa fa-calendar-check-o"></i> Bookings </a></li>
                                                    </ul>
                                                </div>
                                                <!-- user-profile-menu end-->                                        
                                                <!-- <a href="#" class="log-out-btn">Log Out</a> -->
                                            </div>
                                        </div>
                                    </div>
                                    <!-- <div class="col-md-7"> -->
                                    <section>
                                        <!-- <div class="col-list-wrap fh-col-list-wrap  right-list">
                                            <div class="container"> -->
                                                <div class="row">
                                                    <div class="col-md-8">
                                                        <div class="listsearch-header fl-wrap">
                                                            <h3>Results For : <span>All Listings</span></h3>
                                                            <div class="listing-view-layout">
                                                                <ul>
                                                                    <li><a class="grid active" href="#"><i class="fa fa-th-large"></i></a></li>
                                                                    <li><a class="list" href="#"><i class="fa fa-list-ul"></i></a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                        <!-- list-main-wrap-->
                                                        <div class="list-main-wrap fl-wrap card-listing">
                                                            <!-- listing-item -->
                                                            <div class="listing-item">
                                                                <article class="geodir-category-listing fl-wrap">
                                                                    <div class="geodir-category-img">
                                                                        <img src="images/all/8.jpg" alt="">
                                                                        <div class="overlay"></div>
                                                                        <div class="list-post-counter"><span>4</span><i class="fa fa-heart"></i></div>
                                                                    </div>
                                                                    <div class="geodir-category-content fl-wrap">
                                                                        <a class="listing-geodir-category" href="listing.html">Restourants</a>
                                                                        <div class="listing-avatar"><a href="author-single.html"><img src="images/avatar/5.jpg" alt=""></a>
                                                                            <span class="avatar-tooltip">Added By  <strong>Lisa Smith</strong></span>
                                                                        </div>
                                                                        <h3><a href="listing-single.html">Luxury Restourant</a></h3>
                                                                        <p>Sed interdum metus at nisi tempor laoreet. Integer gravida orci a justo sodales, sed lobortis est placerat.</p>
                                                                        <div class="geodir-category-options fl-wrap">
                                                                            <div class="listing-rating card-popup-rainingvis" data-starrating2="5">
                                                                                <span>(7 reviews)</span>
                                                                            </div>
                                                                            <div class="geodir-category-location"><a href="#"><i class="fa fa-map-marker" aria-hidden="true"></i> 27th Brooklyn New York, NY 10065</a></div>
                                                                        </div>
                                                                    </div>
                                                                </article>
                                                            </div>
                                                            <!-- listing-item end-->
                                                            <!-- listing-item -->
                                                            <div class="listing-item">
                                                                <article class="geodir-category-listing fl-wrap">
                                                                    <div class="geodir-category-img">
                                                                        <img src="images/all/1.jpg" alt="">
                                                                        <div class="overlay"></div>
                                                                        <div class="list-post-counter"><span>15</span><i class="fa fa-heart"></i></div>
                                                                    </div>
                                                                    <div class="geodir-category-content fl-wrap">
                                                                        <a class="listing-geodir-category" href="listing.html">Event</a>
                                                                        <div class="listing-avatar"><a href="author-single.html"><img src="images/avatar/2.jpg" alt=""></a>
                                                                            <span class="avatar-tooltip">Added By  <strong>Mark Rose</strong></span>
                                                                        </div>
                                                                        <h3><a href="listing-single.html">Event In City Mol</a></h3>
                                                                        <p>Morbi suscipit erat in diam bibendum rutrum in nisl. Aliquam et purus ante.</p>
                                                                        <div class="geodir-category-options fl-wrap">
                                                                            <div class="listing-rating card-popup-rainingvis" data-starrating2="4">
                                                                                <span>(17 reviews)</span>
                                                                            </div>
                                                                            <div class="geodir-category-location"><a href="#"><i class="fa fa-map-marker" aria-hidden="true"></i> 27th Brooklyn New York, NY 10065</a></div>
                                                                        </div>
                                                                    </div>
                                                                </article>
                                                            </div>
                                                            <!-- listing-item end-->
                                                            <div class="clearfix"></div>
                                                            <!-- listing-item -->
                                                            <div class="listing-item">
                                                                <article class="geodir-category-listing fl-wrap">
                                                                    <div class="geodir-category-img">
                                                                        <img src="images/all/4.jpg" alt="">
                                                                        <div class="overlay"></div>
                                                                        <div class="list-post-counter"><span>553</span><i class="fa fa-heart"></i></div>
                                                                    </div>
                                                                    <div class="geodir-category-content fl-wrap">
                                                                        <a class="listing-geodir-category" href="listing.html">Restourants</a>
                                                                        <div class="listing-avatar"><a href="author-single.html"><img src="images/avatar/3.jpg" alt=""></a>
                                                                            <span class="avatar-tooltip">Added By  <strong>Adam Koncy</strong></span>
                                                                        </div>
                                                                        <h3><a href="listing-single.html">Luxury Restourant</a></h3>
                                                                        <p>Sed non neque elit. Sed ut imperdie.</p>
                                                                        <div class="geodir-category-options fl-wrap">
                                                                            <div class="listing-rating card-popup-rainingvis" data-starrating2="5">
                                                                                <span>(7 reviews)</span>
                                                                            </div>
                                                                            <div class="geodir-category-location"><a href="#"><i class="fa fa-map-marker" aria-hidden="true"></i> 27th Brooklyn New York, NY 10065</a></div>
                                                                        </div>
                                                                    </div>
                                                                </article>
                                                            </div>
                                                            <!-- listing-item end-->
                                                            <!-- listing-item -->
                                                            <div class="listing-item">
                                                                <article class="geodir-category-listing fl-wrap">
                                                                    <div class="geodir-category-img">
                                                                        <img src="images/all/20.jpg" alt="">
                                                                        <div class="overlay"></div>
                                                                        <div class="list-post-counter"><span>47</span><i class="fa fa-heart"></i></div>
                                                                    </div>
                                                                    <div class="geodir-category-content fl-wrap">
                                                                        <a class="listing-geodir-category" href="listing.html">Fitness</a>
                                                                        <div class="listing-avatar"><a href="author-single.html"><img src="images/avatar/4.jpg" alt=""></a>
                                                                            <span class="avatar-tooltip">Added By  <strong>Alisa Noory</strong></span>
                                                                        </div>
                                                                        <h3><a href="listing-single.html">Gym in the Center</a></h3>
                                                                        <p>Mauris in erat justo. Nullam ac urna eu. </p>
                                                                        <div class="geodir-category-options fl-wrap">
                                                                            <div class="listing-rating card-popup-rainingvis" data-starrating2="5">
                                                                                <span>(23 reviews)</span>
                                                                            </div>
                                                                            <div class="geodir-category-location"><a href="#"><i class="fa fa-map-marker" aria-hidden="true"></i> 27th Brooklyn New York, NY 10065</a></div>
                                                                        </div>
                                                                    </div>
                                                                </article>
                                                            </div>
                                                            <!-- listing-item end-->
                                                            <div class="clearfix"></div>
                                                            <!-- listing-item -->
                                                            <div class="listing-item">
                                                                <article class="geodir-category-listing fl-wrap">
                                                                    <div class="geodir-category-img">
                                                                        <img src="images/all/5.jpg" alt="">
                                                                        <div class="overlay"></div>
                                                                        <div class="list-post-counter"><span>3</span><i class="fa fa-heart"></i></div>
                                                                    </div>
                                                                    <div class="geodir-category-content fl-wrap">
                                                                        <a class="listing-geodir-category" href="listing.html">Shops</a>
                                                                        <div class="listing-avatar"><a href="author-single.html"><img src="images/avatar/1.jpg" alt=""></a>
                                                                            <span class="avatar-tooltip">Added By  <strong>Nasty Wood</strong></span>
                                                                        </div>
                                                                        <h3><a href="listing-single.html">Shop in Boutique Zone</a></h3>
                                                                        <p>Morbiaccumsan ipsum velit tincidunt . </p>
                                                                        <div class="geodir-category-options fl-wrap">
                                                                            <div class="listing-rating card-popup-rainingvis" data-starrating2="4">
                                                                                <span>(6 reviews)</span>
                                                                            </div>
                                                                            <div class="geodir-category-location"><a href="#"><i class="fa fa-map-marker" aria-hidden="true"></i> 27th Brooklyn New York, NY 10065</a></div>
                                                                        </div>
                                                                    </div>
                                                                </article>
                                                            </div>
                                                            <!-- listing-item end-->
                                                            <!-- listing-item -->
                                                            <div class="listing-item">
                                                                <article class="geodir-category-listing fl-wrap">
                                                                    <div class="geodir-category-img">
                                                                        <img src="images/all/23.jpg" alt="">
                                                                        <div class="overlay"></div>
                                                                        <div class="list-post-counter"><span>35</span><i class="fa fa-heart"></i></div>
                                                                    </div>
                                                                    <div class="geodir-category-content fl-wrap">
                                                                        <a class="listing-geodir-category" href="listing.html">Hotels</a>
                                                                        <div class="listing-avatar"><a href="author-single.html"><img src="images/avatar/6.jpg" alt=""></a>
                                                                            <span class="avatar-tooltip">Added By  <strong>Kliff Antony</strong></span>
                                                                        </div>
                                                                        <h3><a href="listing-single.html">Luxary Hotel</a></h3>
                                                                        <p>Lorem ipsum gravida nibh vel velit.</p>
                                                                        <div class="geodir-category-options fl-wrap">
                                                                            <div class="listing-rating card-popup-rainingvis" data-starrating2="5">
                                                                                <span>(11 reviews)</span>
                                                                            </div>
                                                                            <div class="geodir-category-location"><a href="#"><i class="fa fa-map-marker" aria-hidden="true"></i> 27th Brooklyn New York, NY 10065</a></div>
                                                                        </div>
                                                                    </div>
                                                                </article>
                                                            </div>
                                                            <!-- listing-item end-->
                                                            <!-- pagination-->
                                                            <div class="pagination">
                                                                <a href="#" class="prevposts-link"><i class="fa fa-caret-left"></i></a>
                                                                <a href="#" class="blog-page transition">1</a>
                                                                <a href="#" class="blog-page current-page transition">2</a>
                                                                <a href="#" class="blog-page transition">3</a>
                                                                <a href="#" class="blog-page transition">4</a>
                                                                <a href="#" class="nextposts-link"><i class="fa fa-caret-right"></i></a>
                                                            </div>
                                                        </div>
                                                        <!-- list-main-wrap end-->
                                                    </div>
                                                   
                                                </div>
                                           <!--  </div>
                                        </div> -->
                                    </section>
                                    <!--  section  end-->
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
            </div>


            <!-- wrapper end -->
            <!--footer -->
            <footer class="main-footer dark-footer  ">
                <div class="container">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="footer-widget fl-wrap">
                                <h3>About Us</h3>
                                <div class="footer-contacts-widget fl-wrap">
                                    <p>In ut odio libero, at vulputate urna. Nulla tristique mi a massa convallis cursus. Nulla eu mi magna. Etiam suscipit commodo gravida. Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam. </p>
                                    <ul  class="footer-contacts fl-wrap">
                                        <li><span><i class="fa fa-envelope-o"></i> Mail :</span><a href="#" target="_blank">yourmail@domain.com</a></li>
                                        <li> <span><i class="fa fa-map-marker"></i> Adress :</span><a href="#" target="_blank">USA 27TH Brooklyn NY</a></li>
                                        <li><span><i class="fa fa-phone"></i> Phone :</span><a href="#">+7(111)123456789</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="footer-widget fl-wrap">
                                <h3>Our Last News</h3>
                                <div class="widget-posts fl-wrap">
                                    <ul>
                                        <li class="clearfix">
                                            <a href="#"  class="widget-posts-img"><img src="images/all/1.jpg" class="respimg" alt=""></a>
                                            <div class="widget-posts-descr">
                                                <a href="#" title="">Vivamus dapibus rutrum</a>
                                                <span class="widget-posts-date"> 21 Mar 09.05 </span>
                                            </div>
                                        </li>
                                        <li class="clearfix">
                                            <a href="#"  class="widget-posts-img"><img src="images/all/2.jpg" class="respimg" alt=""></a>
                                            <div class="widget-posts-descr">
                                                <a href="#" title=""> In hac habitasse platea</a>
                                                <span class="widget-posts-date"> 7 Mar 18.21 </span>
                                            </div>
                                        </li>
                                        <li class="clearfix">
                                            <a href="#"  class="widget-posts-img"><img src="images/all/3.jpg" class="respimg" alt=""></a>
                                            <div class="widget-posts-descr">
                                                <a href="#" title="">Tortor tempor in porta</a>
                                                <span class="widget-posts-date"> 7 Mar 16.42 </span>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="footer-widget fl-wrap">
                                <h3>Our  Twitter</h3>
                                <div id="footer-twiit"></div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="footer-widget fl-wrap">
                                <h3>Subscribe</h3>
                                <div class="subscribe-widget fl-wrap">
                                    <p>Want to be notified when we launch a new template or an udpate. Just sign up and we'll send you a notification by email.</p>
                                    <div class="subcribe-form">
                                        <form id="subscribe">
                                            <input class="enteremail" name="email" id="subscribe-email" placeholder="Email" spellcheck="false" type="text">
                                            <button type="submit" id="subscribe-button" class="subscribe-button"><i class="fa fa-rss"></i> Subscribe</button>
                                            <label for="subscribe-email" class="subscribe-message"></label>
                                        </form>
                                    </div>
                                </div>
                                <div class="footer-widget fl-wrap">
                                    <div class="footer-menu fl-wrap">
                                        <ul>
                                            <li><a href="#">Home </a></li>
                                            <li><a href="#">Blog</a></li>
                                            <li><a href="#">Listing</a></li>
                                            <li><a href="#">Contacts</a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="sub-footer fl-wrap">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="about-widget">
                                    <img src="images/logo.png" alt="">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="copyright"> &#169; Speech 2017 .  All rights reserved.</div>
                            </div>
                            <div class="col-md-4">
                                <div class="footer-social">
                                    <ul>
                                        <li><a href="#" target="_blank" ><i class="fa fa-facebook-official"></i></a></li>
                                        <li><a href="#" target="_blank"><i class="fa fa-twitter"></i></a></li>
                                        <li><a href="#" target="_blank" ><i class="fa fa-chrome"></i></a></li>
                                        <li><a href="#" target="_blank" ><i class="fa fa-vk"></i></a></li>
                                        <li><a href="#" target="_blank" ><i class="fa fa-whatsapp"></i></a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </footer>
            <!--footer end  -->
            <!--register form -->
            <div class="main-register-wrap modal">
                <div class="main-overlay"></div>
                <div class="main-register-holder">
                    <div class="main-register fl-wrap">
                        <div class="close-reg"><i class="fa fa-times"></i></div>
                        <h3>Sign In <span>City<strong>Book</strong></span></h3>
                        <div class="soc-log fl-wrap">
                            <p>For faster login or register use your social account.</p>
                            <a href="#" class="facebook-log"><i class="fa fa-facebook-official"></i>Log in with Facebook</a>
                            <a href="#" class="twitter-log"><i class="fa fa-twitter"></i> Log in with Twitter</a>
                        </div>
                        <div class="log-separator fl-wrap"><span>or</span></div>
                        <div id="tabs-container">
                            <ul class="tabs-menu">
                                <li class="current"><a href="#tab-1">Login</a></li>
                                <li><a href="#tab-2">Register</a></li>
                            </ul>
                            <div class="tab">
                                <div id="tab-1" class="tab-content">
                                    <div class="custom-form">
                                        <form method="post"  name="registerform">
                                            <label>Username or Email Address * </label>
                                            <input name="email" type="text"   onClick="this.select()" value="">
                                            <label >Password * </label>
                                            <input name="password" type="password"   onClick="this.select()" value="" >
                                            <button type="submit"  class="log-submit-btn"><span>Log In</span></button>
                                            <div class="clearfix"></div>
                                            <div class="filter-tags">
                                                <input id="check-aa" type="checkbox" name="check">
                                                <label for="check-aa">Remember me</label>
                                            </div>
                                        </form>
                                        <div class="lost_password">
                                            <a href="#">Lost Your Password?</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="tab">
                                    <div id="tab-2" class="tab-content">
                                        <div class="custom-form">
                                            <form method="post"   name="registerform" class="main-register-form" id="main-register-form2">
                                                <label >First Name * </label>
                                                <input name="name" type="text"   onClick="this.select()" value="">
                                                <label>Second Name *</label>
                                                <input name="name2" type="text"  onClick="this.select()" value="">
                                                <label>Email Address *</label>
                                                <input name="email" type="text"  onClick="this.select()" value="">
                                                <label >Password *</label>
                                                <input name="password" type="password"   onClick="this.select()" value="" >
                                                <button type="submit"     class="log-submit-btn"  ><span>Register</span></button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--register form end -->
            <a class="to-top"><i class="fa fa-angle-up"></i></a>
        </div>
        <!-- Main end -->
        <!--=============== scripts  ===============-->
        <script type="text/javascript" src="js/jquery.min.js"></script>
        <script type="text/javascript" src="js/plugins.js"></script>
        <script type="text/javascript" src="js/scripts.js"></script>
    </body>

<!-- Mirrored from citybook.kwst.net/listing5.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 19 Apr 2018 17:33:44 GMT -->
</html>