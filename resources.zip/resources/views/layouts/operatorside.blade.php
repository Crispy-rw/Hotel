<div class="col-md-3">
<div class="fixed-bar fl-wrap">
    <div class="user-profile-menu-wrap fl-wrap">
        <!-- user-profile-menu-->
        <div class="user-profile-menu">
            <h3>Main</h3>
            <ul>
                <li><a href="#"><i class="fa fa-user-o"></i> Edit profile</a></li>
                <li><a href="#"><i class="fa fa-unlock-alt"></i>Change Password</a></li>
            </ul>
        </div>
        <!-- user-profile-menu end-->
        <!-- user-profile-menu-->
        <div class="user-profile-menu">
            <h3>Listings</h3>
            <ul>
                <li><a href="/hotel"><i class="fa fa-th-list"></i> My Hotel  </a></li>
                <li><a href="/room"><i class="fa fa-hotel"></i> My Rooms  </a></li>
                <li><a href="/operatorbook"> <i class="fa fa-calendar-check-o"></i> Bookings <!-- <span>2</span> --></a></li>
                <li><a href=""><i class="material-icons"></i> Restaurent </a></li>
            </ul>
        </div>
    </div>
</div>
</div>