                                                 
                               
<div class="col-md-3">
    <div class="fixed-bar fl-wrap">
        <div class="user-profile-menu-wrap fl-wrap">
            <div class="user-profile-menu">
                <h3>Listings</h3>
                <ul>
                    <li><a href="#"><i class="fa fa-map-marker"></i> Location  </a></li>
                    <li><a href="/hotelowner" ><i class="fa fa-user-o"></i> Hotel Owners  </a></li>
                    <li><a href="#"><i class="fa fa-hotel"></i>  Hotels </a></li>
                    <li><a href="/roomtype"><i class="fa fa-th-list"></i>  Room Types  </a></li>
                    <li><a href="/adminclients"><i class="fa fa-user-o"></i>  Clients  </a></li>
                    <li><a href="#"> <i class="fa fa-calendar-check-o"></i> Bookings </a></li>
                </ul>
            </div>
        </div>
    </div>
</div>